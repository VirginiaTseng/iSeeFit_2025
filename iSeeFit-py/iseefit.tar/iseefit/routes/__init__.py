"""
Routes package
"""

from . import auth, meals, workouts, recommendations

__all__ = ["auth", "meals", "workouts", "recommendations"]

"""
Services package
"""

from .recommendation_service import RecommendationService

__all__ = ["RecommendationService"]
